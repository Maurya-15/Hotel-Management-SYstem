import numpy as np
import matplotlib.pyplot as plt
import calendar
import datetime
import mysql.connector

# Hardcoded passwords
ADMIN_PASSWORD = "123"  # Replace with your desired admin password

# Initialize the database
def initialize_database():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Replace with your MySQL root password
        database="hotel1"
    )
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(255) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            room_id VARCHAR(255) NOT NULL,
            room_number INT NOT NULL,
            user_name VARCHAR(255) NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            checked_in BOOLEAN DEFAULT FALSE
        )
    ''')
    conn.commit()
    conn.close()

class Room:
    def __init__(self, number, capacity, price):
        self.number = number
        self.capacity = capacity
        self.price = price
        self.is_occupied = False

class BanquetHall:
    def __init__(self, name, capacity, price):
        self.name = name
        self.capacity = capacity
        self.price = price
        self.is_booked = False
        self.function_type = None
        self.booking_date = None

class Staff:
    def __init__(self, name, role):
        self.name = name
        self.role = role

class Hotel:
    def __init__(self, name, rooms_count):
        self.name = name
        self.rooms = [Room(i + 1, np.random.randint(1, 5), np.random.randint(50, 200)) for i in range(rooms_count)]
        self.banquet_hall = BanquetHall("Grand Hall", 100, 500)
        self.staff = [Staff("John", "Cleaner"), Staff("Emily", "Cook")]
        self.booking_data = {}
        self.food_orders = []

    def is_room_available(self, room_number, start_date, end_date):
        """Check if a room is available within the given date range."""
        for booking in self.booking_data.values():
            if booking["room_number"] == room_number:
                booked_start = booking["start_date"]
                booked_end = booking["end_date"]
                if (start_date <= booked_end) and (end_date >= booked_start):
                    return False  # Overlapping booking found
        return True

    def show_available_rooms(self, start_date=None, end_date=None):
        """Show available rooms within a date range (if provided)."""
        available_rooms = [room for room in self.rooms if self.is_room_available(room.number, start_date, end_date)]
        if available_rooms:
            print("\nAvailable Rooms:")
            for room in available_rooms:
                print(f"Room {room.number}: Capacity - {room.capacity}, Price - ${room.price} per night")
        else:
            print("No rooms available for the selected dates.")

    def book_room(self, user_name):
        today = datetime.date.today()
        year = today.year

        try:
            month = int(input("Enter the month for check-in (1-12): "))
            while month < today.month and year == today.year:
                print("You cannot book a past month. Please enter a valid month.")
                month = int(input("Enter the month for check-in (1-12): "))

            print(f"\n{calendar.month(year, month)}")
            start_day = int(input("Enter the start day for booking: "))
            start_date = datetime.date(year, month, start_day)

            if start_date < today:
                print("You cannot book a room for a past date.")
                return

            end_day = int(input("Enter the end day for booking: "))
            end_date = datetime.date(year, month, end_day)

            if end_date < start_date:
                print("End date cannot be before start date.")
                return
        except ValueError:
            print("Invalid date input.")
            return

        available_rooms = [room for room in self.rooms if self.is_room_available(room.number, start_date, end_date)]
        if not available_rooms:
            print("No rooms available for booking.")
            return

        print("\nAvailable Rooms for Booking:")
        for room in available_rooms:
            print(f"Room {room.number}: Capacity - {room.capacity}, Price - ${room.price} per night")

        try:
            room_number = int(input("\nEnter the room number to book: "))
            if not self.is_room_available(room_number, start_date, end_date):
                print("This room is already booked for the selected dates. Please choose another room.")
                return

            room_id = f"R-{room_number}-{np.random.randint(1000, 9999)}"
            self.booking_data[room_id] = {
                "room_number": room_number,
                "user_name": user_name,
                "start_date": start_date,
                "end_date": end_date,
                "checked_in": False
            }

            # Update the room's occupancy status
            for room in self.rooms:
                if room.number == room_number:
                    room.is_occupied = True
                    break

            # Store booking details in the database
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",  # Replace with your MySQL root password
                database="hotel1"
            )
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO bookings (room_id, room_number, user_name, start_date, end_date, checked_in)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (room_id, room_number, user_name, start_date, end_date, False))
            conn.commit()
            conn.close()

            # Generate bill
            total_cost = (end_date - start_date).days * room.price
            bill_content = (f"Bill for Room ID: {room_id}\n"
                             f"User Name: {user_name}\n"
                             f"Room Number: {room_number}\n"
                             f"Start Date: {start_date}\n"
                             f"End Date: {end_date}\n"
                             f"Total Cost: ${total_cost}\n")

            # Write bill to a text file
            with open(f"bill_{room_id}.txt", "w") as file:
                file.write(bill_content)

            print(f"Room {room_number} booked successfully from {start_date} to {end_date}! Your Room ID is: {room_id}")
            print(f"Bill has been generated and saved as bill_{room_id}.txt")
        except ValueError:
            print("Invalid input. Please enter a valid room number.")

    def cancel_booking(self, room_id):
        """Cancel a room booking using the room ID."""
        if room_id in self.booking_data:
            booking = self.booking_data[room_id]
            room_number = booking["room_number"]

            # Update the room's occupancy status
            for room in self.rooms:
                if room.number == room_number:
                    room.is_occupied = False
                    break

            # Remove booking details from the database
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",  # Replace with your MySQL root password
                database="hotel1"
            )
            cursor = conn.cursor()
            cursor.execute("DELETE FROM bookings WHERE room_id = %s", (room_id,))
            conn.commit()
            conn.close()

            del self.booking_data[room_id]
            print(f"Booking for Room ID {room_id} has been canceled successfully.")
            self.show_available_rooms()
        else:
            print("Invalid Room ID.")

    def book_banquet_hall(self, user_name):
        if self.banquet_hall.is_booked:
            print("The banquet hall is already booked.")
            return

        date_str = input("Enter the date for booking (YYYY-MM-DD): ")
        try:
            booking_date = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
            if booking_date < datetime.date.today():
                print("You cannot book for a past date.")
                return
        except ValueError:
            print("Invalid date format.")
            return

        function_type = input("Enter the function type (e.g., Wedding, Conference): ")
        self.banquet_hall.is_booked = True
        self.banquet_hall.function_type = function_type
        self.banquet_hall.booking_date = booking_date
        print(f"Banquet hall booked for {function_type} on {booking_date}!")

    def order_food(self):
        food_item = input("Enter the food item you want to order: ")
        self.food_orders.append(food_item)
        print(f"{food_item} has been ordered successfully!")

    def view_food_items_sold(self):
        if self.food_orders:
            print("Food Items Sold:")
            for item in self.food_orders:
                print(f"- {item}")
        else:
            print("No food items have been sold yet.")

    def check_in(self, room_id):
        """Allow user to check-in only on the booking start date."""
        today = datetime.date.today()
        if room_id in self.booking_data:
            booking = self.booking_data[room_id]
            if booking["start_date"] == today:
                booking["checked_in"] = True

                # Update check-in status in the database
                conn = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",  # Replace with your MySQL root password
                    database="hotel1"
                )
                cursor = conn.cursor()
                cursor.execute("UPDATE bookings SET checked_in = TRUE WHERE room_id = %s", (room_id,))
                conn.commit()
                conn.close()

                print(f"Check-in successful for Room ID: {room_id}")
            else:
                print(f"Check-in allowed only on {booking['start_date']}.")
        else:
            print("Invalid Room ID.")

    def check_out(self, room_id):
        """Allow user to check-out only on or after the booking end date."""
        today = datetime.date.today()
        if room_id in self.booking_data:
            booking = self.booking_data[room_id]

            if not booking["checked_in"]:
                print("You cannot check out without checking in first.")
                return

            if today >= booking["end_date"]:
                print(f"Check-out successful for Room ID: {room_id}")

                # Update the room's occupancy status
                for room in self.rooms:
                    if room.number == booking["room_number"]:
                        room.is_occupied = False
                        break

                del self.booking_data[room_id]
            else:
                print(f"Check-out allowed only on or after {booking['end_date']}.")
        else:
            print("Invalid Room ID.")

    def plot_room_occupancy(self):
        occupied_count = sum(1 for room in self.rooms if room.is_occupied)
        vacant_count = len(self.rooms) - occupied_count

        plt.bar(['Occupied', 'Vacant'], [occupied_count, vacant_count], color=['blue', 'green'])
        plt.title('Room Occupancy')
        plt.xlabel('Status')
        plt.ylabel('Number of Rooms')
        plt.grid(True)
        plt.show()

def authenticate_user(username, password, role):
    if role == 'admin' and password == ADMIN_PASSWORD:
        return True
    elif role == 'user':
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Replace with your MySQL root password
            database="hotel1"
        )
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        conn.close()
        return user is not None
    else:
        print("Invalid credentials.")
        return False

def register_user(username, password):
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Replace with your MySQL root password
        database="hotel1"
    )
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        conn.commit()
        print("User registered successfully!")
        conn.close()
        return True
    except mysql.connector.IntegrityError:
        print("Username already exists. Please choose a different username.")
        conn.close()
        return False

def main():
    initialize_database()
    hotel = Hotel("Cozy Inn", 10)

    while True:
        print("\n1. Admin")
        print("2. User")
        print("3. Exit")

        choice = input("Enter your role: ")

        if choice == "1":
            password = input("Enter admin password: ")
            if authenticate_user(None, password, 'admin'):
                while True:
                    print("\nAdmin Panel")
                    print("1. View Room Occupancy")
                    print("2. View Staff")
                    print("3. Exit Admin Panel")
                    admin_choice = input("Enter your choice: ")

                    if admin_choice == "1":
                        hotel.plot_room_occupancy()
                    elif admin_choice == "2":
                        print("\nHotel Staff:")
                        for staff in hotel.staff:
                            print(f"{staff.name} - {staff.role}")
                    elif admin_choice == "3":
                        break
            else:
                print("Invalid admin credentials.")

        elif choice == "2":
            while True:
                print("\n1. Login")
                print("2. Sign Up")
                print("3. Exit")
                user_choice = input("Enter your choice: ")

                if user_choice == "1":
                    username = input("Enter your username: ")
                    password = input("Enter your password: ")
                    if authenticate_user(username, password, 'user'):
                        while True:
                            print("\nWelcome User!")
                            print("1. Check Available Rooms")
                            print("2. Book Room")
                            print("3. Book Banquet Hall")
                            print("4. Check-In")
                            print("5. Check-Out")
                            print("6. Cancel Booking")
                            print("7. Order Food")
                            print("8. View Room Occupancy")
                            print("9. View Food Items Sold")
                            print("10. Exit")

                            user_choice = input("Enter your choice: ")

                            if user_choice == "1":
                                today = datetime.date.today()
                                end_date = today + datetime.timedelta(days=1)
                                hotel.show_available_rooms(today, end_date)
                            elif user_choice == "2":
                                hotel.book_room(username)
                            elif user_choice == "3":
                                hotel.book_banquet_hall(username)
                            elif user_choice == "4":
                                hotel.check_in(input("Enter Room ID: "))
                            elif user_choice == "5":
                                hotel.check_out(input("Enter Room ID: "))
                            elif user_choice == "6":
                                hotel.cancel_booking(input("Enter Room ID to cancel booking: "))
                            elif user_choice == "7":
                                hotel.order_food()
                            elif user_choice == "8":
                                hotel.plot_room_occupancy()
                            elif user_choice == "9":
                                hotel.view_food_items_sold()
                            elif user_choice == "10":
                                break
                    else:
                        print("Invalid user credentials.")

                elif user_choice == "2":
                    username = input("Enter a new username: ")
                    password = input("Enter a new password: ")
                    if register_user(username, password):
                        print("Registration successful! Please login.")

                elif user_choice == "3":
            
                    break
        elif choice=="3" :
            print("Exiting the Hotel Management System...")
            exit()        

if __name__ == "__main__":
    print("Hotel Management System Starting...")
    main()
